package dev.nuala;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.util.math.Vec3d;

/** Small movement / player modules. */
public final class Modules {
    private Modules() {}

    public static class Fly extends Module {
        public static final float MULT = 3f;
        public Fly() { super("Fly"); }

        @Override public void onTick(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            if (p == null) return;
            PlayerAbilities a = p.getAbilities();
            a.allowFlying = true;
            a.setFlySpeed(0.05f * MULT);
            if (!a.flying && !p.isOnGround()) a.flying = true;
        }

        @Override protected void onDisable() {
            ClientPlayerEntity p = MinecraftClient.getInstance().player;
            if (p == null) return;
            PlayerAbilities a = p.getAbilities();
            a.allowFlying = p.isCreative() || p.isSpectator();
            if (!a.allowFlying) a.flying = false;
            a.setFlySpeed(0.05f);
        }
    }

    public static class Speed extends Module {
        public static final double SPEED = 0.5; // blocks per tick (sprint is ~0.28)
        public Speed() { super("Speed"); }

        @Override public void onTick(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            if (p == null || p.hasVehicle() || p.isTouchingWater() || p.isInLava()) return;
            GameOptions o = mc.options;
            float f = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
            float s = (o.leftKey.isPressed() ? 1 : 0) - (o.rightKey.isPressed() ? 1 : 0);
            if (f == 0 && s == 0) return;
            double yaw = Math.toRadians(p.getYaw());
            double sin = Math.sin(yaw), cos = Math.cos(yaw);
            double dx = -f * sin + s * cos;
            double dz = f * cos + s * sin;
            double len = Math.sqrt(dx * dx + dz * dz);
            dx /= len; dz /= len;
            Vec3d v = p.getVelocity();
            p.setVelocity(dx * SPEED, v.y, dz * SPEED);
        }
    }

    public static class Step extends Module {
        public Step() { super("Step"); }

        private static void set(double value) {
            ClientPlayerEntity p = MinecraftClient.getInstance().player;
            if (p == null) return;
            EntityAttributeInstance inst = p.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
            if (inst != null) inst.setBaseValue(value);
        }

        @Override public void onTick(MinecraftClient mc) { set(2.0); }
        @Override protected void onDisable() { set(0.6); }
    }

    public static class Sprint extends Module {
        public Sprint() { super("Sprint"); }

        @Override public void onTick(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            if (p == null) return;
            if (mc.options.forwardKey.isPressed() && !p.isSneaking() && !p.horizontalCollision) {
                p.setSprinting(true);
            }
        }
    }

    public static class Fullbright extends Module {
        public Fullbright() { super("Fullbright"); }

        @Override public void onTick(MinecraftClient mc) {
            if (mc.player == null) return;
            mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
        }

        @Override protected void onDisable() {
            ClientPlayerEntity p = MinecraftClient.getInstance().player;
            if (p != null) p.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }
}
