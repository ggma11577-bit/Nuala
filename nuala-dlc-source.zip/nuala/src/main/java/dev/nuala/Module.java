package dev.nuala;

import net.minecraft.client.MinecraftClient;

public abstract class Module {
    public final String name;
    public boolean enabled;

    protected Module(String name) { this.name = name; }

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick(MinecraftClient mc) {}
}
