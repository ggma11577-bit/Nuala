package dev.nuala;

import net.minecraft.client.MinecraftClient;
import java.util.List;

public class ModuleManager {
    public static final KillAura KILL_AURA = new KillAura();
    public static final Modules.Fly FLY = new Modules.Fly();
    public static final Modules.Speed SPEED = new Modules.Speed();
    public static final Modules.Step STEP = new Modules.Step();
    public static final Modules.Sprint SPRINT = new Modules.Sprint();
    public static final Modules.Fullbright FULLBRIGHT = new Modules.Fullbright();
    public static final XRay XRAY = new XRay();
    public static final Module ESP = new Module("ESP") {};
    public static final Module TRACERS = new Module("Tracers") {};

    public static final List<Module> all = List.of(
            KILL_AURA, FLY, SPEED, STEP, SPRINT, FULLBRIGHT, XRAY, ESP, TRACERS);

    public static void tick(MinecraftClient mc) {
        for (Module m : all) if (m.enabled) m.onTick(mc);
    }
}
