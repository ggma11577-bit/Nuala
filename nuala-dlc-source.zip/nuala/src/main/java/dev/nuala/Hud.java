package dev.nuala;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;

public class Hud {
    private static final String NAME = "Nuala";

    public static void render(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null) return;
        TextRenderer tr = mc.textRenderer;
        long t = System.currentTimeMillis();

        String fps = mc.getCurrentFps() + " FPS";
        int x = 5, y = 5, h = 20, icon = 16;
        int w = 4 + icon + 5 + tr.getWidth(NAME) + 7 + tr.getWidth(fps) + 7;

        // bar: dark purple gradient + animated rainbow line on top
        ctx.fillGradient(x, y, x + w, y + h, 0xD0201040, 0xD00A0518);
        ctx.fill(x, y, x + w, y + 1, rainbow(t, 0));

        // logo (128x128 texture scaled down)
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(x + 4, y + 2, 0);
        float s = icon / 128f;
        m.scale(s, s, 1f);
        ctx.drawTexture(RenderLayer::getGuiTextured, NualaClient.LOGO, 0, 0, 0f, 0f, 128, 128, 128, 128);
        m.pop();

        // name with rainbow letters
        int cx = x + 4 + icon + 5;
        int ty = y + 6;
        for (char c : NAME.toCharArray()) {
            String str = String.valueOf(c);
            ctx.drawTextWithShadow(tr, str, cx, ty, rainbow(t, cx * 6));
            cx += tr.getWidth(str);
        }

        // separator + FPS
        ctx.fill(cx + 3, y + 4, cx + 4, y + h - 4, 0x66FFFFFF);
        ctx.drawTextWithShadow(tr, fps, cx + 7, ty, 0xFFE6E6E6);

        Overlay.render(ctx, mc, tick.getTickDelta(false));

        // enabled modules list under the bar
        int ly = y + h + 3;
        for (Module mod : ModuleManager.all) {
            if (!mod.enabled) continue;
            int mw = tr.getWidth(mod.name) + 6;
            ctx.fill(x, ly, x + mw, ly + 11, 0x90100820);
            ctx.fill(x, ly, x + 1, ly + 11, rainbow(t, ly * 10));
            ctx.drawTextWithShadow(tr, mod.name, x + 4, ly + 2, 0xFFFFFFFF);
            ly += 12;
        }
    }

    private static int rainbow(long t, int offset) {
        float hue = ((t + offset * 8L) % 3000L) / 3000f;
        return 0xFF000000 | MathHelper.hsvToRgb(hue, 0.6f, 1f);
    }
}
