package dev.nuala;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.registry.Registries;

import java.util.HashMap;
import java.util.Map;

public class XRay extends Module {
    private static final Map<Block, Boolean> CACHE = new HashMap<>();

    public XRay() { super("XRay"); }

    private static void reload() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.worldRenderer != null) mc.worldRenderer.reload();
    }

    @Override protected void onEnable() { reload(); }
    @Override protected void onDisable() { reload(); }

    public static boolean isOn() { return ModuleManager.XRAY.enabled; }

    public static boolean isVisible(BlockState state) {
        return CACHE.computeIfAbsent(state.getBlock(), b -> {
            String p = Registries.BLOCK.getId(b).getPath();
            return p.endsWith("_ore") || p.equals("ancient_debris") || p.equals("spawner")
                    || p.equals("chest") || p.equals("ender_chest") || p.equals("obsidian");
        });
    }
}
