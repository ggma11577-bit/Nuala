package dev.nuala;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

/** 2D ESP / Tracers / Nametags drawn on the HUD (projects world positions to the screen). */
public class Overlay {

    public static void render(DrawContext ctx, MinecraftClient mc, float td) {
        if (mc.world == null || mc.player == null) return;
        boolean esp = ModuleManager.ESP.enabled;
        boolean tracers = ModuleManager.TRACERS.enabled;
        if (!esp && !tracers) return;

        Camera cam = mc.gameRenderer.getCamera();
        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();
        double fov = mc.options.getFov().getValue();
        TextRenderer tr = mc.textRenderer;

        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !e.isAlive()) continue;
            boolean player = e instanceof PlayerEntity;
            if (!player && !(e instanceof HostileEntity)) continue;
            int color = player ? 0xFF55FFFF : 0xFFFF5555;

            Vec3d off = e.getLerpedPos(td).subtract(e.getPos());
            Box b = e.getBoundingBox().offset(off);

            if (tracers) {
                double[] c = project(cam, b.getCenter(), w, h, fov);
                if (c != null) line(ctx, w / 2.0, h, c[0], c[1], color);
            }

            if (esp) {
                double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
                boolean ok = true;
                for (int i = 0; i < 8 && ok; i++) {
                    double x = (i & 1) == 0 ? b.minX : b.maxX;
                    double y = (i & 2) == 0 ? b.minY : b.maxY;
                    double z = (i & 4) == 0 ? b.minZ : b.maxZ;
                    double[] p = project(cam, new Vec3d(x, y, z), w, h, fov);
                    if (p == null) { ok = false; break; }
                    minX = Math.min(minX, p[0]); maxX = Math.max(maxX, p[0]);
                    minY = Math.min(minY, p[1]); maxY = Math.max(maxY, p[1]);
                }
                if (!ok) continue;
                int x1 = (int) minX, y1 = (int) minY, x2 = (int) maxX, y2 = (int) maxY;
                ctx.fill(x1, y1, x2, y1 + 1, color);
                ctx.fill(x1, y2 - 1, x2, y2, color);
                ctx.fill(x1, y1, x1 + 1, y2, color);
                ctx.fill(x2 - 1, y1, x2, y2, color);

                String label = e.getName().getString();
                if (e instanceof LivingEntity le) label += " " + Math.round(le.getHealth()) + "hp";
                label += " " + Math.round(mc.player.distanceTo(e)) + "m";
                ctx.drawCenteredTextWithShadow(tr, label, (x1 + x2) / 2, y1 - 10, 0xFFFFFFFF);
            }
        }
    }

    /** World position -> scaled GUI coordinates, or null if behind the camera. */
    private static double[] project(Camera cam, Vec3d t, int w, int h, double fovDeg) {
        Vec3d rel = t.subtract(cam.getPos());
        double yaw = Math.toRadians(cam.getYaw());
        double pit = Math.toRadians(cam.getPitch());
        double sy = Math.sin(yaw), cy = Math.cos(yaw), sp = Math.sin(pit), cp = Math.cos(pit);

        double fx = -sy * cp, fy = -sp, fz = cy * cp;     // forward
        double rx = -cy, rz = -sy;                        // right
        double ux = -sy * sp, uy = cp, uz = cy * sp;      // up

        double d = rel.x * fx + rel.y * fy + rel.z * fz;
        if (d < 0.05) return null;
        double r = rel.x * rx + rel.z * rz;
        double u = rel.x * ux + rel.y * uy + rel.z * uz;

        double tan = Math.tan(Math.toRadians(fovDeg) / 2.0);
        double aspect = (double) w / h;
        double nx = r / (d * tan * aspect);
        double ny = u / (d * tan);
        return new double[]{ w / 2.0 * (1 + nx), h / 2.0 * (1 - ny) };
    }

    private static void line(DrawContext ctx, double x1, double y1, double x2, double y2, int color) {
        double dx = x2 - x1, dy = y2 - y1;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 1f || len > 5000f) return;
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate((float) x1, (float) y1, 0f);
        m.multiply(RotationAxis.POSITIVE_Z.rotation((float) Math.atan2(dy, dx)));
        ctx.fill(0, 0, (int) len, 1, color);
        m.pop();
    }
}
