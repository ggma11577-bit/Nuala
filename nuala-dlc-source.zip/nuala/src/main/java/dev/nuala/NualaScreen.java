package dev.nuala;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class NualaScreen extends Screen {
    private int idx;

    public NualaScreen() { super(Text.literal("Nuala Dlc")); }

    private ButtonWidget add(Text label, ButtonWidget.PressAction action) {
        int bw = 150, bh = 20, gap = 4;
        int col = idx % 2, row = idx / 2;
        int x = width / 2 - bw - gap / 2 + col * (bw + gap);
        int y = 28 + row * (bh + gap);
        idx++;
        return addDrawableChild(ButtonWidget.builder(label, action).dimensions(x, y, bw, bh).build());
    }

    @Override
    protected void init() {
        idx = 0;
        for (Module m : ModuleManager.all) {
            add(label(m), b -> { m.toggle(); b.setMessage(label(m)); });
        }
        add(mobsLabel(), b -> { KillAura.includeMobs = !KillAura.includeMobs; b.setMessage(mobsLabel()); });

        // Baritone (needs the Baritone mod in mods; it reads the "#" chat prefix)
        baritone("Baritone: diamonds", "#mine diamond_ore");
        baritone("Baritone: debris", "#mine ancient_debris");
        baritone("Baritone: stop", "#stop");
    }

    private void baritone(String label, String cmd) {
        add(Text.literal(label), b -> {
            close();
            if (client != null && client.player != null) client.player.networkHandler.sendChatMessage(cmd);
        });
    }

    private static Text label(Module m) { return Text.literal(m.name + ": " + (m.enabled ? "ON" : "OFF")); }
    private static Text mobsLabel() { return Text.literal("Aura: " + (KillAura.includeMobs ? "players+mobs" : "players")); }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, "Nuala Dlc", width / 2, 12, 0xFFD9B3FF);
    }
}
