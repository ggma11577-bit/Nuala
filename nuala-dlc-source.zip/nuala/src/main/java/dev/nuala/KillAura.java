package dev.nuala;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;

public class KillAura extends Module {
    public static final double RANGE = 4.2;
    /** false = only other players, true = players + hostile mobs */
    public static boolean includeMobs = false;

    public KillAura() { super("KillAura"); }

    @Override
    public void onTick(MinecraftClient mc) {
        // works only in singleplayer / own LAN world (integrated server running)
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.getServer() == null) return;
        if (mc.player.getAttackCooldownProgress(0.5f) < 1.0f) return;

        Entity best = null;
        double bestDist = RANGE * RANGE;
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !e.isAlive()) continue;
            boolean ok = e instanceof PlayerEntity || (includeMobs && e instanceof HostileEntity);
            if (!ok) continue;
            double d = mc.player.squaredDistanceTo(e);
            if (d < bestDist) { bestDist = d; best = e; }
        }
        if (best != null) {
            mc.interactionManager.attackEntity(mc.player, best);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }
}
