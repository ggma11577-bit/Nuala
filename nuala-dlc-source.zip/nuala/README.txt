Nuala Dlc - Fabric 1.21.4
Build (PC): install JDK 21 + Gradle 8.12, then in this folder: gradle build
The jar will be in build/libs/nuala-dlc-1.0.0.jar
Put it + Fabric API 1.21.4 (+ Baritone for 1.21.4) in the mods folder of a Fabric 1.21.4 profile.
In game: Right Shift or /nuala opens the menu.
